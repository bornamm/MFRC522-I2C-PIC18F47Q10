/*/*
 * Prohibited commercial use. Do not use this code for commercial use.
 *
 * Warning: All Right reserveds to respective autors,
 * use this code only reference.
 *
 * The authors are not liable for damages resulting in any way.
 */
/*
 * File name: RFID
 * Creator: Dr.Leong   ( WWW.B2CQSHOP.COM ) (for ARDUINO)
 * Creation date: 2011.09.19
 * Modified by: R
 * Modified date: 2013.09.12
 * Modified: Adapted from Arduino to MikroC and added send serial format RFID-RDM630 by Bluetooth w/ HC-06 slave module
 * Functional Description: Mifare1 Anti-collision find cards - Select card reader interface
 * Modified by: Ahmad Afana
 * Modified date: 2018.12.19
 * Modification: interfacing the rfid (rc522) module with pic18f4550 using soft spi 
 * and providing an example that reads the cards serial number and print it on a lcd 
 */

/*

 *
 * RFID-RC522 MODULE 13.56MHz READER AND WRITER (MFRC522 CHIP) - SPI
 *   RFID-RC522(3.3V) = 3.3V
 *   RFID-RC522(RST) = ANODE DIODE 1N4148 TO PIC
 *   RFID-RC522(GND) = GND
 *   RFID-RC522(SDA) = SlaveSelect (SS) TO PIC

 
 * PIC18F4550 CONECTION:
 * (USE AN 11.0592MHz CRYSTAL FOR BEST RESULTS W/ UART - SERIAL: 9600,8,1,N)
 *   PIN     PORT  FUNCTION    CONNECTION
 *   4       A5    MCLR        OPEN (DISABLE) - ICSP PROG VPP (AT 12V!)
 *   16      A7    OSC1        CRYSTAL 11.0592MHz (PIN1)
 *   15      A6    OSC2        CRYSTAL 11.0592MHz (PIN2)
 *   11      B5    NRSTPD      > KATODE DIODE 1N4148 TO RFID-RC522(RST) (NRSTPD SEE DATASHEET MFRC522)
 *   18      A0    SPI SS      RFID-RC522(SDA) - SlaveSelect (SS)
 *   2       A3    SPI SDI     RFID-RC522(MOSI)
 *   3       A2    SPI SDO     RFID-RC522(MISO)
 *   17      A1    SPI SCK     1RFID-RC522(SCK)
 *   5       GND   GND
 *   14      V+    5V
 *
 */

// Software SPI module connections*/

sbit Chip_Select at RA0_bit;
sbit SoftSpi_SDI at RA3_bit;
sbit SoftSpi_SDO at RA2_bit;
sbit SoftSpi_CLK at RA1_bit;

sbit Chip_Select_Direction at TRISA0_bit;
sbit SoftSpi_SDI_Direction at TRISA3_bit;
sbit SoftSpi_SDO_Direction at TRISA2_bit;
sbit SoftSpi_CLK_Direction at TRISA1_bit;
// End Software SPI module connections
#define  chipSelectPin RA0_bit       // chipSelect (CS) = SlaveSelect (SS)
#define  NRSTPD RB2_bit   // RESET AND POWER DOWN - SEE DATASHEET MFRC522

//Maximum length of the array
#define MAX_LEN 16

/////////////////////////////////////////////////////////////////////
//set the pin
/////////////////////////////////////////////////////////////////////
/*const char chipSelectPin = 10;
const int NRSTPD = 5;*/

//MF522 Command word
#define PCD_IDLE              0x00               //NO action; Cancel the current command
#define PCD_AUTHENT           0x0E               //Authentication Key
#define PCD_RECEIVE           0x08               //Receive Data
#define PCD_TRANSMIT          0x04               //Transmit data
#define PCD_TRANSCEIVE        0x0C               //Transmit and receive data,
#define PCD_RESETPHASE        0x0F               //Reset
#define PCD_CALCCRC           0x03               //CRC Calculate

// Mifare_One card command word
#define PICC_REQIDL          0x26               // find the antenna area does not enter hibernation
#define PICC_REQALL          0x52               // find all the cards antenna area
#define PICC_ANTICOLL        0x93               // anti-collision
#define PICC_SElECTTAG       0x93               // election card
#define PICC_AUTHENT1A       0x60               // authentication key A
#define PICC_AUTHENT1B       0x61               // authentication key B
#define PICC_READ            0x30               // Read Block
#define PICC_WRITE           0xA0               // write block
#define PICC_DECREMENT       0xC0               // debit
#define PICC_INCREMENT       0xC1               // recharge
#define PICC_RESTORE         0xC2               // transfer block data to the buffer
#define PICC_TRANSFER        0xB0               // save the data in the buffer
#define PICC_HALT            0x50               // Sleep

//And MF522 The error code is returned when communication
#define MI_OK                 0
#define MI_NOTAGERR           1
#define MI_ERR                2

//------------------MFRC522 Register---------------
//Page 0:Command and Status
#define     Reserved00            0x00
#define     CommandReg            0x01
#define     CommIEnReg            0x02
#define     DivlEnReg             0x03
#define     CommIrqReg            0x04
#define     DivIrqReg             0x05
#define     ErrorReg              0x06
#define     Status1Reg            0x07
#define     Status2Reg            0x08
#define     FIFODataReg           0x09
#define     FIFOLevelReg          0x0A
#define     WaterLevelReg         0x0B
#define     ControlReg            0x0C
#define     BitFramingReg         0x0D
#define     CollReg               0x0E
#define     Reserved01            0x0F

//Page 1:Command
#define     Reserved10            0x10
#define     ModeReg               0x11
#define     TxModeReg             0x12
#define     RxModeReg             0x13
#define     TxControlReg          0x14
#define     TxAutoReg             0x15
#define     TxSelReg              0x16
#define     RxSelReg              0x17
#define     RxThresholdReg        0x18
#define     DemodReg              0x19
#define     Reserved11            0x1A
#define     Reserved12            0x1B
#define     MifareReg             0x1C
#define     Reserved13            0x1D
#define     Reserved14            0x1E
#define     SerialSpeedReg        0x1F

//Page 2:CFG
#define     Reserved20            0x20
#define     CRCResultRegM         0x21
#define     CRCResultRegL         0x22
#define     Reserved21            0x23
#define     ModWidthReg           0x24
#define     Reserved22            0x25
#define     RFCfgReg              0x26
#define     GsNReg                0x27
#define     CWGsPReg              0x28
#define     ModGsPReg             0x29
#define     TModeReg              0x2A
#define     TPrescalerReg         0x2B
#define     TReloadRegH           0x2C
#define     TReloadRegL           0x2D
#define     TCounterValueRegH     0x2E
#define     TCounterValueRegL     0x2F

//Page 3:TestRegister
#define     Reserved30            0x30
#define     TestSel1Reg           0x31
#define     TestSel2Reg           0x32
#define     TestPinEnReg          0x33
#define     TestPinValueReg       0x34
#define     TestBusReg            0x35
#define     AutoTestReg           0x36
#define     VersionReg            0x37
#define     AnalogTestReg         0x38
#define     TestDAC1Reg           0x39
#define     TestDAC2Reg           0x3A
#define     TestADCReg            0x3B
#define     Reserved31            0x3C
#define     Reserved32            0x3D
#define     Reserved33            0x3E
#define     Reserved34            0x3F
//-----------------------------------------------

#define     uchar                 unsigned char
#define     uint                  unsigned int
#define     boolean               bit
#define     ushort                unsigned short

//4 bytes card serial number, the first 5 bytes for the checksum byte
uchar  serNum[5];

uchar  writeData[16]={0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100};  //Initialization 100 dollars
uchar  moneyConsume = 18 ;  //Consumption of 18 yuan
uchar  moneyAdd = 10 ;  //Recharge 10 yuan
//Sector A password, 16 sectors, each sector password 6Byte
uchar sectorKeyA[16][16] = {{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF},
                            {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF},
                            //{0x19, 0x84, 0x07, 0x15, 0x76, 0x14},
                            {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}, };

uchar sectorNewKeyA[16][16] = {{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF},
                               {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xff,0x07,0x80,0x69, 0x19,0x84,0x07,0x15,0x76,0x14},
                                //you can set another ket , such as  " 0x19, 0x84, 0x07, 0x15, 0x76, 0x14 "
                                //{0x19, 0x84, 0x07, 0x15, 0x76, 0x14, 0xff,0x07,0x80,0x69, 0x19,0x84,0x07,0x15,0x76,0x14},
                                // but when loop, please set the  sectorKeyA, the same key, so that RFID module can read the card
                               {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xff,0x07,0x80,0x69, 0x19,0x33,0x07,0x15,0x34,0x14}, };

uchar old_led = 0;
const ushort inputStringLen = 1;
uchar  inputString[inputStringLen] = "";         // a string to hold incoming data
boolean stringComplete;  // whether the string is complete
ushort bytevar3, bytevar4, Output1, receiv_cnt = 0;
ushort receive[8];
uchar bytevar1, bytevar2 = 0;
uchar uchar_send[8];
uchar read[10];

void delay1ms(uint delayTime);


void SetFormatRDM630(void);
void MFRC522_Init(void);
void TimeOut1(void);
uchar Separate_hexP10(uchar val);
uchar Separate_hexP1(uchar val);
void Write_MFRC522(uchar addr, uchar val);
uchar Read_MFRC522(uchar addr);
void SetBitMask(uchar reg, uchar mask);
void ClearBitMask(uchar reg, uchar mask);
void AntennaOn(void);
void AntennaOff(void);
void MFRC522_Reset(void);
void MFRC522_Init(void);
uchar MFRC522_Request(uchar reqMode, uchar *TagType);
uchar MFRC522_ToCard(uchar command, uchar *sendData, uchar sendLen, uchar *backData, unsigned int *backLen);
uchar MFRC522_Anticoll(uchar *serNum);
void CalulateCRC(uchar *pIndata, uchar len, uchar *pOutData);
uchar MFRC522_SelectTag(uchar *serNum);
uchar MFRC522_Auth(uchar authMode, uchar BlockAddr, uchar *Sectorkey, uchar *serNum);
uchar MFRC522_Read(uchar blockAddr, uchar *recvData);
uchar MFRC522_Write(uchar blockAddr, uchar *writeData);
void MFRC522_Halt(void);



/*
 * Function Name: delay1ms
 * Function Description: delay
 * Input Parameters: none
 * Return value: none
 */
void delay1ms(uint delayTime){
  uint loop1;
  for (loop1=0;loop1<delayTime;loop1++)
  {
    __delay_ms(1);
  }
}

void SetFormatRDM630(void){
  /*uchar checksum1;

  checksum1 = serNum[0] ^ serNum[1] ^ serNum[2] ^ serNum[3] ^ serNum[4];*/
  //uchar_send[0] = 2;

  uchar_send[0] = Separate_hexP10(serNum[0]);
  uchar_send[1] = Separate_hexP1(serNum[0]);
  uchar_send[2] = Separate_hexP10(serNum[1]);
  uchar_send[3] = Separate_hexP1(serNum[1]);
  uchar_send[4] = Separate_hexP10(serNum[2]);
  uchar_send[5] = Separate_hexP1(serNum[2]);
  uchar_send[6] = Separate_hexP10(serNum[3]);
  uchar_send[7] = Separate_hexP1(serNum[3]);
  //uchar_send[9] = Separate_hexP10(serNum[4]);
  //uchar_send[10] = Separate_hexP1(serNum[4]);

 // uchar_send[11] = Separate_hexP10(checksum1);
  //uchar_send[12] = Separate_hexP1(checksum1);

  //uchar_send[13] = 3;
 // uchar_send[14] = 0;
 read[0]= uchar_send[0];
 read[1]= uchar_send[1];
 read[2]= uchar_send[2];
 read[3]= uchar_send[3];
 read[4]= uchar_send[4];
 read[5]= uchar_send[5];
 read[6]= uchar_send[6];
 read[7]= uchar_send[7];

}
/*
 * Function Name: TimeOut1
 * Function Description: TimeOut1 to reset bluetooth module ("key" pin) +/- 10s
 * Input Parameters: none
 * Return value: none
 */



/*
  SerialEvent occurs whenever a new data comes in the
 hardware serial RX.  This routine is run between each
 time loop() runs, so using delay inside loop can delay
 response.  Multiple bytes of data may be available.
 */
/*
 * RECEIVING:
 * A remote device sends by bluetooth a frame with string "#ON1#" for change the output "Output1" to state HIGH.
 * A remote device sends by bluetooth a frame with string "#OFF1#" for change the output "Output1" to state LOW.
 * ANY DATA RECEIVED CLEARS THE TIMEOUT TO RESET BLUETOOTH MODULE
 */
/*
 * Function Name: INTERRUPT
 * Function Description: SerialEvent occurs
 * Input Parameters: none
 * Return value: none
 */
void interrupt(void){
  ushort RCREG_temp = 0;

  if (PIR1.RCIF) // USART Receive Interrupt Flag bit
  {
    PIR1.RCIF = 0;
    bytevar3=0; // CLEAR THE TIMEOUT TO RESET BLUETOOTH MODULE
    bytevar4=0; // CLEAR THE TIMEOUT TO RESET BLUETOOTH MODULE
    RCREG_temp = RCREG;

    if (RCREG_temp == 35)  // 35 = "#" - (# ???)
    {
      receiv_cnt = 0;
    }
    else
    {
       receiv_cnt++;
    }
    receive[receiv_cnt] = RCREG_temp;

    if (receive[2] == 70) // 70 = "F"  - (#OFF1# ???)
    {
       receive[2] = 0;
       Output1 = 0;
       stringComplete = 1;
    }
    if (receive[2] == 78)  // 78 = "N" - (#ON1# ???)
    {
       receive[2] = 0;
       Output1 = 1;
       stringComplete = 1;
    }
  }
}

/*
 * Function Name: Separate_hexP10
 * Function Description: To strip data high from full data
 * Input Parameters: val - the value to be strip
 * Return value: Part High
 */
uchar Separate_hexP10(uchar val){
  val = val & 0xF0;
  val = val >> 4;
  if (val < 10)
  {
      return val + 48;
  }
  else
  {
      return val + 55;
  }
}

/*
 * Function Name: Separate_hexP1
 * Function Description: To strip data low from full data
 * Input Parameters: val - the value to be strip
 * Return value: Part Low
 */
uchar Separate_hexP1(uchar val){
  val = val & 0x0F;
  if (val < 10)
  {
      return val + 48;
  }
  else
  {
      return val + 55;
  }
}

/*
 * Function Name: Write_MFRC5200
 * Function Description: To a certain MFRC522 register to write a byte of data
 * Input Parameters: addr - register address; val - the value to be written
 * Return value: None
 */
void Write_MFRC522(uchar addr, uchar val){
  chipSelectPin = 0;

  //Address Format: 0XXXXXX0
  Soft_SPI_Write((addr<<1)&0x7E);
  Soft_SPI_Write(val);

  chipSelectPin = 1;
}


/*
 * Function Name: Read_MFRC522
 * Description: From a certain MFRC522 read a byte of data register
 * Input Parameters: addr - register address
 * Returns: a byte of data read from the
 */
uchar Read_MFRC522(uchar addr){
  uchar val;

  chipSelectPin = 0;

  //Address Format: 1XXXXXX0
  Soft_SPI_Write(((addr<<1)&0x7E) | 0x80);
  val = Soft_SPI_Read(0x00);

  chipSelectPin = 1;

  return val;
}

/*
 * Function Name: SetBitMask
 * Description: Set RC522 register bit
 * Input parameters: reg - register address; mask - set value
 * Return value: None
 */
void SetBitMask(uchar reg, uchar mask){
  uchar tmp;
  tmp = Read_MFRC522(reg);
  Write_MFRC522(reg, tmp | mask);  // set bit mask
}


/*
 * Function Name: ClearBitMask
 * Description: clear RC522 register bit
 * Input parameters: reg - register address; mask - clear bit value
 * Return value: None
*/
void ClearBitMask(uchar reg, uchar mask){
  uchar tmp;
  tmp = Read_MFRC522(reg);
  Write_MFRC522(reg, tmp & (~mask));  // clear bit mask
}


/*
 * Function Name: AntennaOn
 * Description: Open antennas, each time you start or shut down the natural barrier between the transmitter should be at least 1ms interval
 * Input: None
 * Return value: None
 */
void AntennaOn(void){
  uchar temp;

  temp = Read_MFRC522(TxControlReg);
  if (!(temp & 0x03))
  {
    SetBitMask(TxControlReg, 0x03);
}
}


/*
  * Function Name: AntennaOff
  * Description: Close antennas, each time you start or shut down the natural barrier between the transmitter should be at least 1ms interval
  * Input: None
  * Return value: None
 */
void AntennaOff(void){
  ClearBitMask(TxControlReg, 0x03);
}


/*
 * Function Name: ResetMFRC522
 * Description: Reset RC522
 * Input: None
 * Return value: None
 */
void MFRC522_Reset(void){
  Write_MFRC522(CommandReg, PCD_RESETPHASE);
}


/*
 * Function Name: InitMFRC522
 * Description: Initialize RC522
 * Input: None
 * Return value: None
*/
void MFRC522_Init(void){
  NRSTPD = 1;

  MFRC522_Reset();

  //Timer: TPrescaler*TreloadVal/6.78MHz = 24ms
  Write_MFRC522(TModeReg, 0x8D);                //Tauto=1; f(Timer) = 6.78MHz/TPreScaler
  Write_MFRC522(TPrescalerReg, 0x3E);        //TModeReg[3..0] + TPrescalerReg
  Write_MFRC522(TReloadRegL, 30);
  Write_MFRC522(TReloadRegH, 0);

  Write_MFRC522(TxAutoReg, 0x40);                //100%ASK
  Write_MFRC522(ModeReg, 0x3D);                //CRC Initial value 0x6363        ???

  //ClearBitMask(Status2Reg, 0x08);                //MFCrypto1On=0
  //Write_MFRC522(RxSelReg, 0x86);                //RxWait = RxSelReg[5..0]
  //Write_MFRC522(RFCfgReg, 0x7F);                   //RxGain = 48dB

  AntennaOn();                //Open the antenna
}


/*
 * Function Name: MFRC522_Request
 * Description: Find cards, read the card type number
 * Input parameters: reqMode - find cards way
 *                         TagType - Return Card Type
 *                                 0x4400 = Mifare_UltraLight
 *                                0x0400 = Mifare_One(S50)
 *                                0x0200 = Mifare_One(S70)
 *                                0x0800 = Mifare_Pro(X)
 *                                0x4403 = Mifare_DESFire
 * Return value: the successful return MI_OK
 */
uchar MFRC522_Request(uchar reqMode, uchar *TagType){
  uchar status;
  uint backBits;                        //The received data bits

  Write_MFRC522(BitFramingReg, 0x07);                //TxLastBists = BitFramingReg[2..0]        ???

  TagType[0] = reqMode;
  status = MFRC522_ToCard(PCD_TRANSCEIVE, TagType, 1, TagType, &backBits);

  if ((status != MI_OK) || (backBits != 0x10))
  {
    status = MI_ERR;
  }

  return status;
}


/*
 * Function Name: MFRC522_ToCard
 * Description: RC522 and ISO14443 card communication
 * Input Parameters: command - MF522 command word,
 *                         sendData--RC522 sent to the card by the data
 *                         sendLen--Length of data sent
 *                         backData--Received the card returns data,
 *                         backLen--Return data bit length
 * Return value: the successful return MI_OK
 */
uchar MFRC522_ToCard(uchar command, uchar *sendData, uchar sendLen, uchar *backData, uint *backLen){
  uchar status = MI_ERR;
  uchar irqEn = 0x00;
  uchar waitIRq = 0x00;
  uchar lastBits;
  uchar n;
  uint i;

  switch (command)
  {
    case PCD_AUTHENT:                //Certification cards close
    {
      irqEn = 0x12;
      waitIRq = 0x10;
      break;
    }
    case PCD_TRANSCEIVE:        //Transmit FIFO data
    {
      irqEn = 0x77;
      waitIRq = 0x30;
      break;
    }
    default:
      break;
  }

  Write_MFRC522(CommIEnReg, irqEn|0x80);        //Interrupt request
  ClearBitMask(CommIrqReg, 0x80);                        //Clear all interrupt request bit
  SetBitMask(FIFOLevelReg, 0x80);                        //FlushBuffer=1, FIFO Initialization

  Write_MFRC522(CommandReg, PCD_IDLE);        //NO action; Cancel the current command???

  //Writing data to the FIFO
  for (i=0; i<sendLen; i++)
  {
    Write_MFRC522(FIFODataReg, sendData[i]);
  }

  //Execute the command
  Write_MFRC522(CommandReg, command);
  if (command == PCD_TRANSCEIVE)
  {
    SetBitMask(BitFramingReg, 0x80);                //StartSend=1,transmission of data starts
  }

  //Waiting to receive data to complete
  i = 2000;        //i according to the clock frequency adjustment, the operator M1 card maximum waiting time 25ms???
  do
  {
    //CommIrqReg[7..0]
    //Set1 TxIRq RxIRq IdleIRq HiAlerIRq LoAlertIRq ErrIRq TimerIRq
    n = Read_MFRC522(CommIrqReg);
    i--;
  }
  while ((i!=0) && !(n&0x01) && !(n&waitIRq));

  ClearBitMask(BitFramingReg, 0x80);                        //StartSend=0

  if (i != 0)
  {
    if(!(Read_MFRC522(ErrorReg) & 0x1B))        //BufferOvfl Collerr CRCErr ProtecolErr
    {
      status = MI_OK;
      if (n & irqEn & 0x01)
      {
        status = MI_NOTAGERR;                        //??
      }

      if (command == PCD_TRANSCEIVE)
      {
        n = Read_MFRC522(FIFOLevelReg);
        lastBits = Read_MFRC522(ControlReg) & 0x07;
        if (lastBits)
        {
          *backLen = (n-1)*8 + lastBits;
        }
        else
        {
          *backLen = n*8;
        }

        if (n == 0)
        {
          n = 1;
        }
        if (n > MAX_LEN)
        {
          n = MAX_LEN;
        }

        //Reading the received data in FIFO
        for (i=0; i<n; i++)
        {
          backData[i] = Read_MFRC522(FIFODataReg);
        }
      }
    }
    else
    {
      status = MI_ERR;
    }

  }

  //SetBitMask(ControlReg,0x80);           //timer stops
  //Write_MFRC522(CommandReg, PCD_IDLE);

  return status;
}


/*
 * Function Name: MFRC522_Anticoll
 * Description: Anti-collision detection, reading selected card serial number card
 * Input parameters: serNum - returns 4 bytes card serial number, the first 5 bytes for the checksum byte
 * Return value: the successful return MI_OK
 */
uchar MFRC522_Anticoll(uchar *serNum){
  uchar status;
  uchar i;
  uchar serNumCheck=0;
  uint unLen;


  //ClearBitMask(Status2Reg, 0x08);                //TempSensclear
  //ClearBitMask(CollReg,0x80);                        //ValuesAfterColl
  Write_MFRC522(BitFramingReg, 0x00);                //TxLastBists = BitFramingReg[2..0]

  serNum[0] = PICC_ANTICOLL;
  serNum[1] = 0x20;
  status = MFRC522_ToCard(PCD_TRANSCEIVE, serNum, 2, serNum, &unLen);

  if (status == MI_OK)
  {
    //Check card serial number
    for (i=0; i<4; i++)
    {
      serNumCheck ^= serNum[i];
    }
    if (serNumCheck != serNum[i])
    {
      status = MI_ERR;
    }
  }

  //SetBitMask(CollReg, 0x80);                //ValuesAfterColl=1

  return status;
}
/*
 * Function Name: CalulateCRC
 * Description: CRC calculation with MF522
 * Input parameters: pIndata - To read the CRC data, len - the data length, pOutData - CRC calculation results
 * Return value: None
 */
void CalulateCRC(uchar *pIndata, uchar len, uchar *pOutData){
  uchar i, n;

  ClearBitMask(DivIrqReg, 0x04);                        //CRCIrq = 0
  SetBitMask(FIFOLevelReg, 0x80);                        //Clear the FIFO pointer
  //Write_MFRC522(CommandReg, PCD_IDLE);

  //Writing data to the FIFO
  for (i=0; i<len; i++)
  {
    Write_MFRC522(FIFODataReg, *(pIndata+i));
  }
  Write_MFRC522(CommandReg, PCD_CALCCRC);

  //Wait CRC calculation is complete
  i = 0xFF;
  do
  {
    n = Read_MFRC522(DivIrqReg);
    i--;
  }
  while ((i!=0) && !(n&0x04));                        //CRCIrq = 1

  //Read CRC calculation result
  pOutData[0] = Read_MFRC522(CRCResultRegL);
  pOutData[1] = Read_MFRC522(CRCResultRegM);
}
/*
 * Function Name: MFRC522_SelectTag
 * Description: election card, read the card memory capacity
 * Input parameters: serNum - Incoming card serial number
 * Return value: the successful return of card capacity
 */
uchar MFRC522_SelectTag(uchar *serNum){
  uchar i;
  uchar status;
  uchar size;
  uint recvBits;
  uchar buffer[9];

  //ClearBitMask(Status2Reg, 0x08);                        //MFCrypto1On=0

  buffer[0] = PICC_SElECTTAG;
  buffer[1] = 0x70;
  for (i=0; i<5; i++)
  {
    buffer[i+2] = *(serNum+i);
  }
  CalulateCRC(buffer, 7, &buffer[7]);                //??
  status = MFRC522_ToCard(PCD_TRANSCEIVE, buffer, 9, buffer, &recvBits);

  if ((status == MI_OK) && (recvBits == 0x18))
  {
    size = buffer[0];
  }
  else
  {
    size = 0;
  }

  return size;
}
/*
 * Function Name: MFRC522_Auth
 * Description: Verify card password
 * Input parameters: authMode - Password Authentication Mode
                 0x60 = A key authentication
                 0x61 = Authentication Key B
             BlockAddr--Block address
             Sectorkey--Sector password
             serNum--Card serial number, 4-byte
 * Return value: the successful return MI_OK
 */
uchar MFRC522_Auth(uchar authMode, uchar BlockAddr, uchar *Sectorkey, uchar *serNum){
  uchar status;
  uint recvBits;
  uchar i;
  uchar buff[12];

  //Verify the command block address + sector + password + card serial number
  buff[0] = authMode;
  buff[1] = BlockAddr;
  for (i=0; i<6; i++)
  {
    buff[i+2] = *(Sectorkey+i);
  }
  for (i=0; i<4; i++)
  {
    buff[i+8] = *(serNum+i);
  }
  status = MFRC522_ToCard(PCD_AUTHENT, buff, 12, buff, &recvBits);

  if ((status != MI_OK) || (!(Read_MFRC522(Status2Reg) & 0x08)))
  {
    status = MI_ERR;
  }

  return status;
}
/*
 * Function Name: MFRC522_Read
 * Description: Read block data
 * Input parameters: blockAddr - block address; recvData - read block data
 * Return value: the successful return MI_OK
 */
uchar MFRC522_Read(uchar blockAddr, uchar *recvData){
  uchar status;
  uint unLen;

  recvData[0] = PICC_READ;
  recvData[1] = blockAddr;
  CalulateCRC(recvData,2, &recvData[2]);
  status = MFRC522_ToCard(PCD_TRANSCEIVE, recvData, 4, recvData, &unLen);

  if ((status != MI_OK) || (unLen != 0x90))
  {
    status = MI_ERR;
  }

  return status;
}
/*
 * Function Name: MFRC522_Write
 * Description: Write block data
 * Input parameters: blockAddr - block address; writeData - to 16-byte data block write
 * Return value: the successful return MI_OK
 */
uchar MFRC522_Write(uchar blockAddr, uchar *writeData){
  uchar status;
  uint recvBits;
  uchar i;
  uchar buff[18];

  buff[0] = PICC_WRITE;
  buff[1] = blockAddr;
  CalulateCRC(buff, 2, &buff[2]);
  status = MFRC522_ToCard(PCD_TRANSCEIVE, buff, 4, buff, &recvBits);

  if ((status != MI_OK) || (recvBits != 4) || ((buff[0] & 0x0F) != 0x0A))
  {
    status = MI_ERR;
  }

  if (status == MI_OK)
  {
    for (i=0; i<16; i++)                //Data to the FIFO write 16Byte
    {
      buff[i] = *(writeData+i);
    }
    CalulateCRC(buff, 16, &buff[16]);
    status = MFRC522_ToCard(PCD_TRANSCEIVE, buff, 18, buff, &recvBits);

    if ((status != MI_OK) || (recvBits != 4) || ((buff[0] & 0x0F) != 0x0A))
    {
      status = MI_ERR;
    }
  }

  return status;
}
/*
 * Function Name: MFRC522_Halt
 * Description: Command card into hibernation
 * Input: None
 * Return value: None
 */
void MFRC522_Halt(void){
  uchar status;
  uint unLen;
  uchar buff[4];

  buff[0] = PICC_HALT;
  buff[1] = 0;
  CalulateCRC(buff, 2, &buff[2]);

  status = MFRC522_ToCard(PCD_TRANSCEIVE, buff, 4, buff,&unLen);
}